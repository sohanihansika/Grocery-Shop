from pydantic import BaseModel

class Product(BaseModel):
    id: int
    name: str
    description: str
    price: float
    quantity: int

    # Pydantic v2: allow creating this model from ORM/SQLAlchemy objects
    # so FastAPI can return SQLAlchemy rows directly when using response_model.
    model_config = {"from_attributes": True}

